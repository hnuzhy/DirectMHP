from sixdrepnet.regressor import SixDRepNet_Detector as SixDRepNet


"""
6DRepNet.

Accurate and unconstrained head pose estimation.
"""

__version__ = "0.1.2"
__author__ = 'Thorsten Hempel'
